import { useEffect, useState } from "react";

const useFetch = (url) => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true);

    setTimeout(() => {
      try {
        // throw new Error("error fetching data!");

        setData(url);
        setLoading(false);
      } catch (e) {
        setError(e.message);
      }
    }, 1000);
  }, [url]);
  return { data, error, loading };
};
export default useFetch;
