import "./App.css";
import ProductsLayOut from "./layouts/ProductsLayOut/ProductsLayOut";
import ProductsGridContainer from "./components/ProductsGrid/ProductsGridContainer";
function App() {
  return (
    <div>
      <ProductsLayOut background="blue">
        <ProductsGridContainer />
      </ProductsLayOut>
    </div>
  );
}

export default App;
