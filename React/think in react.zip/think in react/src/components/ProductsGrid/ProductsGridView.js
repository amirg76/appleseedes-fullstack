import Card from "../Card/Card.js";
import "./productsGrid.styles.css";
const ProductsGridView = ({ data }) => {
  const renderCards = () => {
    return data.map((item, i) => {
      return <Card key={i} item={item} />;
    });
  };

  return <div className="container">{renderCards()}</div>;
};
export default ProductsGridView;
