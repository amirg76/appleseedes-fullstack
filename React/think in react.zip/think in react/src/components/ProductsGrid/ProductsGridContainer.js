import { useEffect, useState } from "react";
import useFetch from "../../hooks/useFetch";
import items from "../../items";
import ProductsGridView from "./ProductsGridView";

const ProductsGridContainer = () => {
  const { data, loading, error } = useFetch(items);
  //   const [data, setData] = useState([]);
  //   const [loading, setLoading] = useState(false);
  // const [error,setError] = useState(false);

  // useEffect(() => {
  //   setLoading(true);
  //   setTimeout(() => {
  //     try {
  //       //  throw new Error("error fetching!");
  //       setData(items);
  //       setLoading(false);
  //     } catch (e) {
  //       setLoading(false);
  //       setError(e.message);
  //     }
  //   }, 1000);
  // }, []);

  //   console.log({ loading });
  if (loading) return <div>Spinner</div>;
  if (error) return <div>{error}</div>;
  return (
    <div>
      <ProductsGridView data={data} />
    </div>
  );
};
export default ProductsGridContainer;
