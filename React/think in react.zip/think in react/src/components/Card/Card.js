import "./card.styles.css";

const Cards = ({ item: { title, images } }) => {
  const renderImages = () => {
    const isOneImage = images.length === 1 ? "big" : "small";
    return images.map((url, i) => {
      return <img key={i} className={isOneImage} src={url} />;
    });
  };

  return (
    <div className="card-container">
      <h3>{title}</h3>
      <div className="images-container">{renderImages()}</div>
    </div>
  );
};

export default Cards;
