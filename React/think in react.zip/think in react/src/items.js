const items = [
  {
    title: "Pick up where you left off",
    images: [
      "https://m.media-amazon.com/images/I/717zWgjbLQL._AC_SY110_.jpg",
      "https://m.media-amazon.com/images/I/611Rmnv0NAL._AC_SY110_.jpg",
      "https://m.media-amazon.com/images/I/81S-xWVH8kL._AC_SY110_.jpg",
      "https://m.media-amazon.com/images/I/61XYX1tzoTL._AC_SY110_.jpg",
    ],
  },
  {
    title: "Free Shipping to israel",
    images: [
      "https://images-na.ssl-images-amazon.com/images/G/01/AmazonExports/Projects/JumpIn/379x304._SY304_CB449506705_.jpg",
    ],
  },
];
export default items;
