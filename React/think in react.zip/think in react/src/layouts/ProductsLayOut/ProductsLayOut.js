import "./productsLayOut.css";
const ProductsLayOut = ({ children, background }) => {
  //changing the background. Few solutions:
  //1. With JS using inline
  const styles = {
    background,
    height: "100vh",
  };
  //2 with classNames
  const className = `background-${background}`;
  return (
    // <div style={styles}>
    <div className={className}>
      <div className="layout">{children}</div>
    </div>
  );
};
export default ProductsLayOut;
